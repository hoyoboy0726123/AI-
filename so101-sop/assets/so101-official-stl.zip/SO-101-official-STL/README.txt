SO-101 official STL files (unmodified copies)

Source: https://github.com/TheRobotStudio/SO-ARM100
Commit: a758567c3978dfeefe282ede0500085a48fe8f78 (2026-10-06)
Paths: STL/SO101/Individual/*.stl and STL/Gauges/*.STL
License: Apache License 2.0, see LICENSE in this folder.
Full print plates (Ender / Prusa / Bambu A1 mini) are in STL/SO101/Follower and STL/SO101/Leader of the source repository.
